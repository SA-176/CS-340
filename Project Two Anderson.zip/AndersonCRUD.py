from pymongo import MongoClient
from bson.objectid import ObjectId

import json

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):

        # Connection Variables
        #
        #USER = 'aacuser'
        #PASS = 'Animal123'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30035
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (username,password,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        
        print("Connected test")

# Complete this create method to implement the C in CRUD.
    def create(self, createData):
        if createData is not None:
            cursor = self.database.animals.insert(createData)  # data should be dictionary 
            if cursor is not None:
                status = True
            else:
                status = False
            return status
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Create method to implement the R in CRUD.
    def read(self, readData):
        cursor = []
        if readData is not None:
            cursor = self.database.animals.find(readData)
            return cursor
            #for animals in cursor:
                #print(animals)
                
        else:
            raise Exception("Enter a criteria to search")
        
# method implementaion of the U in CRUD
    def update(self, searchData, updateData):
        if searchData:
            result = self.database.animals.update_many(searchData, {"$set": updateData})
            resultUpdate = ("Docs updated: " + json.dumps(result.modified_count))        
            return resultUpdate
        else:
            raise Exception("No Record Found")
        print("Data Updated")

# method implementaion of the D in CRUD
    def delete(self, deleteData):
        if deleteData is not None:
            result = self.database.animals.delete_many(deleteData)
            resultDelete = "Docs deleted: " + json.dumps(result.deleted_count)
            if resultDelete == 0:
                print("Error, didn't find document")
            return resultDelete
        else:
            raise Exception("Nothing to Delete")
        print("Data Deleted")